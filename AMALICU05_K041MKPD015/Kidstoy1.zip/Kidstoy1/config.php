<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
//Tidak dapat membuat sambungan dengan database config.php
?>
