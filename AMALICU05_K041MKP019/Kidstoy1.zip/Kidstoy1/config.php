<?php 
//komen $connect=mysqli_connect("localhost:3306", "root","123456","barang") or die("failed...");
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
?>
