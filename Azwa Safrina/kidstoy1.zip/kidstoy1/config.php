<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed..."); //buang password dan nombor
?>
