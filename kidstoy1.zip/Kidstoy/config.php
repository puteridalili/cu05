<?php 
$connect=mysqli_connect("", "root","","barang") or die("failed...");
?>
