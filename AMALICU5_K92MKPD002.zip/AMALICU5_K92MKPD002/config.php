<?php 
$connect=mysqli_connect("localhost:3306", "root","123456","barangmainan") or die("failed...");
?>
